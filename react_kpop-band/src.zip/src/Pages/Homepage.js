import React from 'react';
import "./Homepage.css"

function Homepage() {
    return (
        <div className="backgroundPic">
            
            
        </div>
    )
}

export default Homepage
